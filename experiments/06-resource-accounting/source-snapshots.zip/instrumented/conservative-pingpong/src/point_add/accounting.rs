use super::*;
use std::collections::BTreeMap;
use std::io::Write;

type Owner = (&'static str, &'static str, u32);

#[derive(Default)]
pub struct Accounting {
    live: BTreeMap<u64, Owner>,
    peaks: BTreeMap<&'static str, (usize, usize, BTreeMap<Owner, usize>)>,
    pub rounds: Vec<(usize, usize)>,
}

impl B {
    pub(crate) fn accounting_round(&mut self, round: usize) {
        self.accounting.rounds.push((self.current_ops_len(), round));
    }

    fn accounting_label(&self, phase: &str, index: usize) -> String {
        let round = self.accounting.rounds.iter().rev().find(|(i, _)| *i <= index).map(|(_, r)| *r);
        if round == Some(0) && (phase.contains("gcd") || phase.contains("apply")) {
            format!("{phase}_initial")
        } else { phase.to_string() }
    }
    pub(crate) fn accounting_alloc(&mut self, q: u64, file: &'static str, line: u32) {
        let (file, line) = self.b0.batch_ctx.unwrap_or((file, line));
        assert!(self.accounting.live.insert(q, (self.phase, file, line)).is_none(), "duplicate live allocation {q}");
        self.accounting_sample();
    }

    pub(crate) fn accounting_free(&mut self, q: u64) {
        assert!(self.accounting.live.remove(&q).is_some(), "free of unowned qubit {q}");
        assert_eq!(self.accounting.live.len(), self.active_qubits as usize);
    }

    pub(crate) fn accounting_sample(&mut self) {
        assert_eq!(self.accounting.live.len(), self.active_qubits as usize);
        let n = self.accounting.live.len();
        if n > self.accounting.peaks.get(self.phase).map_or(0, |p| p.0) {
            let mut owners = BTreeMap::new();
            for owner in self.accounting.live.values() { *owners.entry(*owner).or_insert(0) += 1; }
            self.accounting.peaks.insert(self.phase, (n, self.current_ops_len(), owners));
        }
    }

    pub(crate) fn accounting_dump(&mut self) {
        let Ok(dir) = std::env::var("ACCOUNTING_DIR") else { return; };
        self.close_counted_phase();
        let mut f = std::fs::File::create(format!("{dir}/owners.tsv")).unwrap();
        writeln!(f, "peak_phase\tactive\top_index\tallocation_phase\tfile\tline\tcount").unwrap();
        for (phase, (active, index, owners)) in &self.accounting.peaks {
            assert_eq!(*active, owners.values().sum::<usize>());
            for ((allocated, file, line), count) in owners {
                writeln!(f, "{phase}\t{active}\t{index}\t{allocated}\t{file}\t{line}\t{count}").unwrap();
            }
        }
        let mut f = std::fs::File::create(format!("{dir}/phases.tsv")).unwrap();
        writeln!(f, "phase\tstart\tend\tops\tccx\tccz\thmr\treset").unwrap();
        if self.count_only {
            for p in &self.counted_phase_rows {
                writeln!(f, "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}", self.accounting_label(p.phase, p.start), p.start, p.end, p.ops, p.ccx_ops, p.ccz_ops, p.hmr_ops, p.r_ops).unwrap();
            }
        } else {
            let mut bounds = vec![(0, "init")];
            bounds.extend_from_slice(&self.phase_transitions);
            bounds.push((self.ops.len(), "end"));
            for w in bounds.windows(2) {
                let (start, phase) = w[0];
                let end = w[1].0;
                assert!(end >= start && end <= self.ops.len());
                let mut counts = [0usize; 18];
                for op in &self.ops[start..end] { counts[op.kind as usize] += 1; }
                if end > start { writeln!(f, "{}\t{start}\t{end}\t{}\t{}\t{}\t{}\t{}", self.accounting_label(phase, start), end-start, counts[13], counts[14], counts[12], counts[11]).unwrap(); }
            }
        }
        let mut f = std::fs::File::create(format!("{dir}/allocator.tsv")).unwrap();
        writeln!(f, "peak_qubits\t{}\nmax_wire_plus_one\t{}\npeak_phase\t{}\npeak_op_index\t{}\nfinal_active\t{}\ncount_only\t{}\nprecompiler_ops\t{}", self.peak_qubits, self.next_qubit, self.peak_phase, self.peak_ops_idx, self.active_qubits, self.count_only, self.current_ops_len()).unwrap();
        let mut env: Vec<_> = std::env::vars().collect();
        env.sort();
        let mut f = std::fs::File::create(format!("{dir}/emitter-settings.tsv")).unwrap();
        for (k, v) in env {
            if ["SUB4_", "TLM_", "DIALOG_", "QIP_", "WINDOWED_", "CONSTPROP_", "W1155_", "ACCOUNTING_", "SINGLE_", "KAL_", "ROUND", "SQUARE_", "LUD_"].iter().any(|p| k.starts_with(p)) { writeln!(f, "{k}\t{v}").unwrap(); }
        }
        if self.count_only { std::process::exit(0); }
    }
}
