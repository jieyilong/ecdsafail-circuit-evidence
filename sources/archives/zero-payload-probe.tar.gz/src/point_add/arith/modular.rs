
use super::*;

pub(crate) fn mod_add_qq(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {
    let n = acc.len();
    assert_eq!(n, a.len());
    debug_assert_eq!(n, 256);

    let (acc_ext, acc_ovf) = ext_reg(b, acc);
    let (a_ext, a_ovf) = ext_reg(b, a);

    add_nbit_qq(b, &a_ext, &acc_ext);

    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    add_nbit_const(b, &acc_ext, c);

    let flag = b.alloc_qubit();
    b.cx(acc_ovf, flag);

    b.x(flag);
    csub_nbit_const(b, &acc_ext, c, flag);
    b.x(flag);

    b.cx(flag, acc_ovf);

    cmp_lt_into(b, &acc_ext[..n], &a_ext[..n], flag);
    b.free(flag);

    unext_reg(b, a_ovf);
    unext_reg(b, acc_ovf);
    let _ = (acc_ext, a_ext);
}

pub(crate) fn mod_sub_qq(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {

    let a_copy: Vec<QubitId> = a.to_vec();
    emit_inverse(b, move |b| mod_add_qq(b, acc, &a_copy, p));
}

pub(crate) fn mod_add_qq_lowq(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {
    let n = acc.len();
    assert_eq!(n, a.len());
    debug_assert_eq!(n, 256);

    let (acc_ext, acc_ovf) = ext_reg(b, acc);
    let (a_ext, a_ovf) = ext_reg(b, a);

    add_nbit_qq(b, &a_ext, &acc_ext);

    let borrow = if r84_lowq_cin_borrow_enabled() {
        Some(a_ovf)
    } else {
        None
    };

    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    add_nbit_const_extcarry_clean_with_cin(b, &acc_ext, c, borrow);

    let flag = b.alloc_qubit();
    b.cx(acc_ovf, flag);

    b.x(flag);
    csub_nbit_const_extcarry_clean_with_cin(b, &acc_ext, c, flag, borrow);
    b.x(flag);

    b.cx(flag, acc_ovf);

    cmp_lt_into(b, &acc_ext[..n], &a_ext[..n], flag);
    b.free(flag);

    unext_reg(b, a_ovf);
    unext_reg(b, acc_ovf);
    let _ = (acc_ext, a_ext);
}

pub(crate) fn mod_sub_qq_lowq(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {
    let a_copy: Vec<QubitId> = a.to_vec();
    emit_inverse(b, move |b| mod_add_qq_lowq(b, acc, &a_copy, p));
}

pub(crate) fn mod_sub_qq_fast(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {
    let n = acc.len();
    assert_eq!(n, a.len());
    debug_assert_eq!(n, 256);

    let (acc_ext, acc_ovf) = ext_reg(b, acc);
    let (a_ext, a_ovf) = ext_reg(b, a);

    sub_nbit_qq_fast(b, &a_ext, &acc_ext);

    let flag = b.alloc_qubit();
    b.cx(acc_ovf, flag);

    b.cx(flag, acc_ovf);

    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    if kal_vent_modadd_enabled() {

        let c_low = c.as_limbs()[0];
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::cisub_dirty_2clean_classical(
            b,
            &acc_ext[..n],
            &a_ext[..n - 2],
            &q_clean2,
            c_low,
            flag,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    } else if secp_direct_const_arith_enabled() {
        csub_nbit_const_direct_fast(b, &acc_ext[..n], c, flag);
    } else {
        csub_nbit_const_fast(b, &acc_ext[..n], c, flag);
    }

    b.x(flag);
    mod_neg_inplace_fast(b, &a_ext[..n], p);
    if std::env::var("MOD_FAST_FLAG_CONDITIONAL_REPLAY").ok().as_deref() == Some("1") {
        let phase = b.alloc_bit();
        b.hmr(flag, phase);
        cmp_lt_phase_conditioned(b, &acc_ext[..n], &a_ext[..n], phase);
    } else {
        cmp_lt_into_fast(b, &acc_ext[..n], &a_ext[..n], flag);
    }
    mod_neg_inplace_fast(b, &a_ext[..n], p);
    b.free(flag);

    unext_reg(b, a_ovf);
    unext_reg(b, acc_ovf);
    let _ = (acc_ext, a_ext);
}

pub(crate) fn mod_add_qq_vent(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {
    let n = acc.len();
    assert_eq!(n, a.len());
    debug_assert_eq!(n, 256);

    let (acc_ext, acc_ovf) = ext_reg(b, acc);
    let (a_ext, a_ovf) = ext_reg(b, a);

    add_nbit_qq(b, &a_ext, &acc_ext);

    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    let c_low = c.as_limbs()[0];
    let n1 = acc_ext.len();
    {
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::iadd_dirty_2clean_classical(
            b,
            &acc_ext,
            &a_ext[..n1 - 2],
            &q_clean2,
            c_low,
            false,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    }

    let flag = b.alloc_qubit();
    b.cx(acc_ovf, flag);

    b.x(flag);
    {
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::cisub_dirty_2clean_classical(
            b,
            &acc_ext,
            &a_ext[..n1 - 2],
            &q_clean2,
            c_low,
            flag,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    }
    b.x(flag);

    b.cx(flag, acc_ovf);

    cmp_lt_into(b, &acc_ext[..n], &a_ext[..n], flag);
    b.free(flag);

    unext_reg(b, a_ovf);
    unext_reg(b, acc_ovf);
    let _ = (acc_ext, a_ext);
}

pub(crate) fn mod_sub_qq_vent(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {
    let n = acc.len();
    assert_eq!(n, a.len());
    debug_assert_eq!(n, 256);

    let (acc_ext, acc_ovf) = ext_reg(b, acc);
    let (a_ext, a_ovf) = ext_reg(b, a);

    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    let c_low = c.as_limbs()[0];
    let n1 = acc_ext.len();

    let flag = b.alloc_qubit();
    cmp_lt_into(b, &acc_ext[..n], &a_ext[..n], flag);

    b.cx(flag, acc_ovf);

    b.x(flag);
    {
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::ciadd_dirty_2clean_classical(
            b,
            &acc_ext,
            &a_ext[..n1 - 2],
            &q_clean2,
            c_low,
            flag,
            false,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    }
    b.x(flag);

    b.cx(acc_ovf, flag);
    b.free(flag);

    {
        let one = b.alloc_qubit();
        b.x(one);
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::cisub_dirty_2clean_classical(b, &acc_ext, &a_ext[..n1 - 2], &q_clean2, c_low, one);
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
        b.x(one);
        b.free(one);
    }

    sub_nbit_qq(b, &a_ext, &acc_ext);

    unext_reg(b, a_ovf);
    unext_reg(b, acc_ovf);
    let _ = (acc_ext, a_ext);
}

pub(crate) fn mod_neg_inplace_fast(b: &mut B, v: &[QubitId], p: U256) {
    for &q in v {
        b.x(q);
    }
    let n = v.len();
    let ca = load_const(b, n, p.wrapping_add(U256::from(1)));
    add_nbit_qq_fast(b, &ca, v);
    unload_const(b, &ca, p.wrapping_add(U256::from(1)));
}

pub(crate) fn mod_add_qb(b: &mut B, acc: &[QubitId], bits: &[BitId], p: U256) {

    let a = load_bits(b, bits);
    if std::env::var("MOD_ADD_QB_VENT").ok().as_deref() != Some("0") {

        mod_add_qq_vent(b, acc, &a, p);
    } else {
        mod_add_qq_fast(b, acc, &a, p);
    }
    unload_bits(b, &a, bits);
}

pub(crate) fn mod_add_double_qb(b: &mut B, acc: &[QubitId], bits: &[BitId], p: U256) {

    let a = load_bits(b, bits);
    mod_double_inplace_fast(b, &a, p);
    if std::env::var("MOD_ADD_DOUBLE_QB_VENT").ok().as_deref() != Some("0") {

        mod_add_qq_vent(b, acc, &a, p);
    } else {
        mod_add_qq_fast(b, acc, &a, p);
    }
    mod_halve_inplace_fast(b, &a, p);
    unload_bits(b, &a, bits);
}

pub(crate) fn mod_sub_qb(b: &mut B, acc: &[QubitId], bits: &[BitId], p: U256) {

    let a = load_bits(b, bits);
    if std::env::var("MOD_SUB_QB_VENT").ok().as_deref() != Some("0") {

        mod_sub_qq_vent(b, acc, &a, p);
    } else {
        mod_sub_qq_fast(b, acc, &a, p);
    }
    unload_bits(b, &a, bits);
}

pub(crate) fn mod_add_triple_qb(b: &mut B, acc: &[QubitId], bits: &[BitId], p: U256) {
    let n = bits.len();
    let a = load_bits(b, bits);
    let d = b.alloc_qubits(n);
    for i in 0..n {
        b.cx(a[i], d[i]);
    }
    mod_double_inplace_fast(b, &d, p);
    mod_add_qq_vent(b, acc, &d, p);
    mod_add_qq_vent(b, acc, &a, p);
    mod_halve_inplace_fast(b, &d, p);
    for i in 0..n {
        b.cx(a[i], d[i]);
    }
    b.free_vec(&d);
    unload_bits(b, &a, bits);
}

pub(crate) fn mod_const_minus_reg_qb(b: &mut B, tx: &[QubitId], bits: &[BitId], p: U256) {
    let n = tx.len();
    assert_eq!(n, bits.len());
    let a = load_bits(b, bits);
    let (a_ext, a_ovf) = ext_reg(b, &a);
    let (tx_ext, tx_ovf) = ext_reg(b, tx);
    for i in 0..n {
        b.x(tx_ext[i]);
    }
    let cin = b.alloc_qubit();
    b.x(cin);
    cuccaro_add_low_to_ext_clean(b, &a, &tx_ext, cin);
    b.x(cin);
    b.free(cin);
    let flag = b.alloc_qubit();
    b.cx(tx_ovf, flag);
    b.cx(flag, tx_ovf);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    let c_low = c.as_limbs()[0];
    let n1 = tx_ext.len();
    b.x(flag);
    {
        let q2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::cisub_dirty_2clean_classical(b, &tx_ext, &a_ext[..n1 - 2], &q2, c_low, flag);
        b.free(q2[0]);
        b.free(q2[1]);
    }
    b.x(flag);
    b.x(flag);
    cmp_lt_into(b, &a, &tx_ext[..n], flag);
    b.free(flag);
    unext_reg(b, tx_ovf);
    unext_reg(b, a_ovf);
    let _ = (tx_ext, a_ext);
    unload_bits(b, &a, bits);
}

pub(crate) fn dialog_fuse_primitive_selftest() -> Result<(), String> {
    use crate::sim::Simulator;
    use sha3::digest::{ExtendableOutput, Update, XofReader};
    let p = crate::point_add::SECP256K1_P;
    let nbits = 256usize;
    let red = |v: U256| v % p;
    let sub_modp = |x: U256, y: U256| -> U256 {
        if x >= y {
            x - y
        } else {
            p - (y - x)
        }
    };
    for fuse_x_restore in [false, true] {
        let name = if fuse_x_restore {
            "mod_const_minus_reg_qb (FUSE_X_RESTORE)"
        } else {
            "mod_add_triple_qb (FUSE_C_FORM)"
        };
        let mut bld = B::new();
        let tx = bld.alloc_qubits(nbits);
        let qx = bld.alloc_bits(nbits);
        if fuse_x_restore {
            mod_const_minus_reg_qb(&mut bld, &tx, &qx, p);
        } else {
            mod_add_triple_qb(&mut bld, &tx, &qx, p);
        }
        let (ops, nq, nb) = (bld.ops, bld.next_qubit as usize, bld.next_bit as usize);
        let mut seed = sha3::Shake256::default();
        seed.update(b"dialog-fuse-primitive-selftest");
        seed.update(&[u8::from(fuse_x_restore)]);
        let mut xof = seed.finalize_xof();

        let mut txv = [U256::ZERO; 64];
        let mut qxv = [U256::ZERO; 64];
        let mut buf = [0u8; 32];
        for shot in 0..64 {
            xof.read(&mut buf);
            txv[shot] = red(U256::from_le_bytes(buf));
            xof.read(&mut buf);
            qxv[shot] = red(U256::from_le_bytes(buf));
        }
        let mut sim = Simulator::new(nq, nb, &mut xof);
        sim.clear_for_shot();
        for shot in 0..64 {
            for i in 0..nbits {
                if txv[shot].bit(i) {
                    *sim.qubit_mut(tx[i]) |= 1u64 << shot;
                }
                if qxv[shot].bit(i) {
                    *sim.bit_mut(qx[i]) |= 1u64 << shot;
                }
            }
        }
        sim.apply_iter(ops.iter());
        if sim.phase != 0 {
            return Err(format!("{name}: phase garbage 0x{:x}", sim.phase));
        }
        for shot in 0..64 {
            let mut out = U256::ZERO;
            for i in 0..nbits {
                if (sim.qubit(tx[i]) >> shot) & 1 == 1 {
                    out |= U256::from(1u64) << i;
                }
            }
            let expect = if fuse_x_restore {
                sub_modp(qxv[shot], txv[shot])
            } else {
                txv[shot].add_mod(qxv[shot].mul_mod(U256::from(3u64), p), p)
            };
            if out != expect {
                return Err(format!(
                    "{name}: shot {shot} got {out:#x} expect {expect:#x} (tx={:#x} qx={:#x})",
                    txv[shot], qxv[shot]
                ));
            }
        }
        for q in 0..nq as u64 {
            if tx.iter().any(|t| t.0 == q) {
                continue;
            }
            let v = sim.qubit(QubitId(q));
            if v != 0 {
                return Err(format!("{name}: ancilla qubit {q} not clean = 0x{v:x}"));
            }
        }
    }
    Ok(())
}

pub(crate) fn mod_double_inplace_fast(b: &mut B, v: &[QubitId], p: U256) {
    mod_double_inplace_fast_with_dirty(b, v, p, None)
}

pub(crate) fn mod_double_inplace_fast_with_dirty(
    b: &mut B,
    v: &[QubitId],
    p: U256,
    dirty_src: Option<&[QubitId]>,
) {
    let n = v.len();
    let ovf = b.alloc_qubit();
    b.swap(v[n - 1], ovf);
    for i in (0..n - 1).rev() {
        b.swap(v[i], v[i + 1]);
    }
    debug_assert_eq!(n, 256);

    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    let use_venting = std::env::var("KAL_VENT_DOUBLE").ok().as_deref() == Some("1")
        && dirty_src.map_or(false, |d| d.len() >= n - 2);
    if let Some(w) = double_carry_trunc_window() {

        cadd_nbit_const_direct_trunc_fast(b, v, c, ovf, w);
    } else if use_venting {
        let dirty = dirty_src.unwrap();
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::ciadd_dirty_2clean_classical(
            b,
            v,
            &dirty[..n - 2],
            &q_clean2,
            c.as_limbs()[0],
            ovf,
            false,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    } else if direct_const_walks_enabled()
        || std::env::var("KAL_DIRECT_CONST_DOUBLE").ok().as_deref() == Some("1")
    {
        cadd_nbit_const_direct_fast(b, v, c, ovf);
    } else {
        cadd_nbit_const_fast(b, v, c, ovf);
    }

    b.cx(v[0], ovf);
    b.free(ovf);
}

pub(crate) fn mod_double_inplace_direct_const_fast(b: &mut B, v: &[QubitId], p: U256) {
    let n = v.len();
    let ovf = b.alloc_qubit();
    b.swap(v[n - 1], ovf);
    for i in (0..n - 1).rev() {
        b.swap(v[i], v[i + 1]);
    }
    debug_assert_eq!(n, 256);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    cadd_nbit_const_direct_fast(b, v, c, ovf);
    b.cx(v[0], ovf);
    b.free(ovf);
}

pub(crate) fn lowq_shift22() -> bool {
    if d1_phase_corrected_product_core_active() {
        return true;
    }

    match std::env::var("LOWQ_SHIFT22") {
        Ok(v) => v != "0",
        Err(_) => false,
    }
}

pub(crate) fn mod_shift_left_by_k(
    b: &mut B,
    v: &[QubitId],
    p: U256,
    k: usize,
) -> (Vec<QubitId>, QubitId, QubitId) {
    let n = v.len();
    debug_assert_eq!(n, 256);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));

    let spill = b.alloc_qubits(k);
    let ovf = b.alloc_qubit();
    let flag_inv = b.alloc_qubit();

    for shift_i in 0..k {
        b.swap(v[n - 1], spill[k - 1 - shift_i]);
        for i in (0..n - 1).rev() {
            b.swap(v[i], v[i + 1]);
        }
    }

    let mut v_ext = v.to_vec();
    v_ext.push(ovf);
    let cuccaro_op = |b: &mut B, pos: usize, is_sub: bool| {
        let pad_width = n + 1 - pos;
        let padded = b.alloc_qubits(pad_width);
        for i in 0..k.min(pad_width) {
            b.cx(spill[i], padded[i]);
        }
        let v_slice: Vec<QubitId> = v_ext[pos..n + 1].to_vec();
        let c_in = b.alloc_qubit();
        if lowq_shift22() {
            if is_sub {
                cuccaro_sub(b, &padded, &v_slice, c_in);
            } else {
                cuccaro_add(b, &padded, &v_slice, c_in);
            }
        } else if is_sub {

            cuccaro_sub_fast(b, &padded, &v_slice, c_in);
        } else {
            cuccaro_add_fast(b, &padded, &v_slice, c_in);
        }
        b.free(c_in);
        for i in 0..k.min(pad_width) {
            b.cx(spill[i], padded[i]);
        }
        b.free_vec(&padded);
    };
    b.set_phase("shift22_cuccaro_op_0");
    cuccaro_op(b, 0, false);
    b.set_phase("shift22_cuccaro_op_4");
    cuccaro_op(b, 4, false);
    b.set_phase("shift22_cuccaro_op_6");
    cuccaro_op(b, 6, true);
    b.set_phase("shift22_cuccaro_op_10");
    cuccaro_op(b, 10, false);
    b.set_phase("shift22_cuccaro_op_32");
    cuccaro_op(b, 32, false);

    b.set_phase("shift22_step3");
    if lowq_shift22() {
        add_nbit_const(b, &v_ext, c);
    } else {
        add_nbit_const_fast(b, &v_ext, c);
    }
    b.x(ovf);
    b.cx(ovf, flag_inv);
    b.x(ovf);

    b.set_phase("shift22_step4");
    if lowq_shift22() {
        csub_nbit_const(b, &v_ext, c, flag_inv);
    } else {
        csub_nbit_const_fast(b, &v_ext, c, flag_inv);
    }
    b.x(flag_inv);
    b.cx(flag_inv, ovf);
    b.x(flag_inv);

    (spill, flag_inv, ovf)
}

pub(crate) fn mod_shift_right_by_k(
    b: &mut B,
    v: &[QubitId],
    p: U256,
    k: usize,
    spill: Vec<QubitId>,
    flag_inv: QubitId,
    ovf: QubitId,
) {
    let n = v.len();
    debug_assert_eq!(n, 256);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));

    let mut v_ext = v.to_vec();
    v_ext.push(ovf);

    b.x(flag_inv);
    b.cx(flag_inv, ovf);
    b.x(flag_inv);
    b.set_phase("rshift22_rev_step4");
    if lowq_shift22() {
        cadd_nbit_const(b, &v_ext, c, flag_inv);
    } else {
        cadd_nbit_const_fast(b, &v_ext, c, flag_inv);
    }

    b.x(ovf);
    b.cx(ovf, flag_inv);
    b.x(ovf);
    b.set_phase("rshift22_rev_step3");
    if lowq_shift22() {
        sub_nbit_const(b, &v_ext, c);
    } else {
        sub_nbit_const_fast(b, &v_ext, c);
    }
    b.free(flag_inv);
    b.set_phase("rshift22_rev_step2");

    let cuccaro_op = |b: &mut B, pos: usize, is_sub: bool| {
        let pad_width = n + 1 - pos;
        let padded = b.alloc_qubits(pad_width);
        for i in 0..k.min(pad_width) {
            b.cx(spill[i], padded[i]);
        }
        let v_slice: Vec<QubitId> = v_ext[pos..n + 1].to_vec();
        let c_in = b.alloc_qubit();
        if lowq_shift22() {
            if is_sub {
                cuccaro_sub(b, &padded, &v_slice, c_in);
            } else {
                cuccaro_add(b, &padded, &v_slice, c_in);
            }
        } else if is_sub {
            cuccaro_sub_fast(b, &padded, &v_slice, c_in);
        } else {
            cuccaro_add_fast(b, &padded, &v_slice, c_in);
        }
        b.free(c_in);
        for i in 0..k.min(pad_width) {
            b.cx(spill[i], padded[i]);
        }
        b.free_vec(&padded);
    };

    cuccaro_op(b, 32, true);
    cuccaro_op(b, 10, true);
    cuccaro_op(b, 6, false);
    cuccaro_op(b, 4, true);
    cuccaro_op(b, 0, true);

    for shift_i in (0..k).rev() {
        for i in 0..n - 1 {
            b.swap(v[i], v[i + 1]);
        }
        b.swap(v[n - 1], spill[k - 1 - shift_i]);
    }

    b.free(ovf);
    b.free_vec(&spill);
}

pub(crate) fn mod_shift_left_by_k_lowq(
    b: &mut B,
    v: &[QubitId],
    p: U256,
    k: usize,
) -> (Vec<QubitId>, QubitId, QubitId) {
    let n = v.len();
    debug_assert_eq!(n, 256);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));

    let spill = b.alloc_qubits(k);
    let ovf = b.alloc_qubit();
    let flag_inv = b.alloc_qubit();

    for shift_i in 0..k {
        b.swap(v[n - 1], spill[k - 1 - shift_i]);
        for i in (0..n - 1).rev() {
            b.swap(v[i], v[i + 1]);
        }
    }

    let mut v_ext = v.to_vec();
    v_ext.push(ovf);
    let cuccaro_op = |b: &mut B, pos: usize, is_sub: bool| {
        let pad_width = n + 1 - pos;
        let padded = b.alloc_qubits(pad_width);
        for i in 0..k.min(pad_width) {
            b.cx(spill[i], padded[i]);
        }
        let v_slice: Vec<QubitId> = v_ext[pos..n + 1].to_vec();
        let c_in = b.alloc_qubit();
        if is_sub {
            cuccaro_sub(b, &padded, &v_slice, c_in);
        } else {
            cuccaro_add(b, &padded, &v_slice, c_in);
        }
        b.free(c_in);
        for i in 0..k.min(pad_width) {
            b.cx(spill[i], padded[i]);
        }
        b.free_vec(&padded);
    };
    cuccaro_op(b, 0, false);
    cuccaro_op(b, 4, false);
    cuccaro_op(b, 6, true);
    cuccaro_op(b, 10, false);
    cuccaro_op(b, 32, false);

    add_nbit_const(b, &v_ext, c);
    b.x(ovf);
    b.cx(ovf, flag_inv);
    b.x(ovf);
    csub_nbit_const(b, &v_ext, c, flag_inv);
    b.x(flag_inv);
    b.cx(flag_inv, ovf);
    b.x(flag_inv);

    (spill, flag_inv, ovf)
}

pub(crate) fn mod_shift_right_by_k_lowq(
    b: &mut B,
    v: &[QubitId],
    p: U256,
    k: usize,
    spill: Vec<QubitId>,
    flag_inv: QubitId,
    ovf: QubitId,
) {
    let n = v.len();
    debug_assert_eq!(n, 256);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));

    let mut v_ext = v.to_vec();
    v_ext.push(ovf);

    b.x(flag_inv);
    b.cx(flag_inv, ovf);
    b.x(flag_inv);
    cadd_nbit_const(b, &v_ext, c, flag_inv);

    b.x(ovf);
    b.cx(ovf, flag_inv);
    b.x(ovf);
    sub_nbit_const(b, &v_ext, c);
    b.free(flag_inv);

    let cuccaro_op = |b: &mut B, pos: usize, is_sub: bool| {
        let pad_width = n + 1 - pos;
        let padded = b.alloc_qubits(pad_width);
        for i in 0..k.min(pad_width) {
            b.cx(spill[i], padded[i]);
        }
        let v_slice: Vec<QubitId> = v_ext[pos..n + 1].to_vec();
        let c_in = b.alloc_qubit();
        if is_sub {
            cuccaro_sub(b, &padded, &v_slice, c_in);
        } else {
            cuccaro_add(b, &padded, &v_slice, c_in);
        }
        b.free(c_in);
        for i in 0..k.min(pad_width) {
            b.cx(spill[i], padded[i]);
        }
        b.free_vec(&padded);
    };
    cuccaro_op(b, 32, true);
    cuccaro_op(b, 10, true);
    cuccaro_op(b, 6, false);
    cuccaro_op(b, 4, true);
    cuccaro_op(b, 0, true);

    for shift_i in (0..k).rev() {
        for i in 0..n - 1 {
            b.swap(v[i], v[i + 1]);
        }
        b.swap(v[n - 1], spill[k - 1 - shift_i]);
    }

    b.free(ovf);
    b.free_vec(&spill);
}

pub(crate) fn mod_halve_inplace_fast(b: &mut B, v: &[QubitId], p: U256) {
    mod_halve_inplace_fast_with_dirty(b, v, p, None)
}

pub(crate) fn mod_halve_inplace_direct_const_fast(b: &mut B, v: &[QubitId], p: U256) {
    let n = v.len();
    let ovf = b.alloc_qubit();
    debug_assert_eq!(n, 256);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    b.cx(v[0], ovf);
    csub_nbit_const_direct_fast(b, v, c, ovf);
    for i in 0..n - 1 {
        b.swap(v[i], v[i + 1]);
    }
    b.swap(v[n - 1], ovf);
    b.free(ovf);
}

pub(crate) fn mod_halve_inplace_fast_with_dirty(
    b: &mut B,
    v: &[QubitId],
    p: U256,
    dirty_src: Option<&[QubitId]>,
) {
    let n = v.len();
    let ovf = b.alloc_qubit();
    debug_assert_eq!(n, 256);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    b.cx(v[0], ovf);

    let use_venting = kal_vent_halve_enabled() && dirty_src.map_or(false, |d| d.len() >= n - 2);
    if let Some(w) = double_carry_trunc_window() {

        csub_nbit_const_direct_trunc_fast(b, v, c, ovf, w);
    } else if use_venting {

        let c_u64: u64 = c.as_limbs()[0] | (c.as_limbs()[1] << 32);

        let c_low = c.as_limbs()[0];
        let dirty = dirty_src.unwrap();
        let dirty_slice = &dirty[..n - 2];

        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::cisub_dirty_2clean_classical(b, v, dirty_slice, &q_clean2, c_low, ovf);
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
        let _ = c_u64;
    } else if direct_const_walks_enabled()
        || std::env::var("KAL_DIRECT_CONST_HALVE").ok().as_deref() == Some("1")
    {
        csub_nbit_const_direct_fast(b, v, c, ovf);
    } else {
        csub_nbit_const_fast(b, v, c, ovf);
    }
    for i in 0..n - 1 {
        b.swap(v[i], v[i + 1]);
    }
    b.swap(v[n - 1], ovf);
    b.free(ovf);
}

pub(crate) fn cmod_double_inplace_lazy(b: &mut B, v: &[QubitId], p: U256, ctrl: QubitId) {
    let n = v.len();
    let ovf = b.alloc_qubit();
    cswap(b, ctrl, v[n - 1], ovf);
    for i in (0..n - 1).rev() {
        cswap(b, ctrl, v[i], v[i + 1]);
    }
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    if let Some(w) = double_carry_trunc_window() {
        cadd_nbit_const_direct_trunc_fast(b, v, c, ovf, w);
    } else if direct_const_walks_enabled()
        || std::env::var("KAL_DIRECT_CONST_DOUBLE").ok().as_deref() == Some("1")
    {
        cadd_nbit_const_direct_fast(b, v, c, ovf);
    } else {
        cadd_nbit_const_fast(b, v, c, ovf);
    }

    b.ccx(ctrl, v[0], ovf);
    b.free(ovf);
}

pub(crate) fn cmod_halve_inplace_lazy(b: &mut B, v: &[QubitId], p: U256, ctrl: QubitId) {
    let n = v.len();
    let ovf = b.alloc_qubit();
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    b.ccx(ctrl, v[0], ovf);
    if let Some(w) = double_carry_trunc_window() {
        csub_nbit_const_direct_trunc_fast(b, v, c, ovf, w);
    } else if direct_const_walks_enabled()
        || std::env::var("KAL_DIRECT_CONST_HALVE").ok().as_deref() == Some("1")
    {
        csub_nbit_const_direct_fast(b, v, c, ovf);
    } else {
        csub_nbit_const_fast(b, v, c, ovf);
    }
    for i in 0..n - 1 {
        cswap(b, ctrl, v[i], v[i + 1]);
    }
    cswap(b, ctrl, v[n - 1], ovf);
    b.free(ovf);
}

pub(crate) fn mod_add_qq_fast(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {
    let n = acc.len();
    assert_eq!(n, a.len());
    debug_assert_eq!(n, 256);

    let (acc_ext, acc_ovf) = ext_reg(b, acc);
    let (a_ext, a_ovf) = ext_reg(b, a);

    add_nbit_qq_fast(b, &a_ext, &acc_ext);
    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));

    let use_vent = kal_vent_modadd_enabled();
    if use_vent {
        let n1 = acc_ext.len();

        let c_low = c.as_limbs()[0];
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::iadd_dirty_2clean_classical(
            b,
            &acc_ext,
            &a_ext[..n1 - 2],
            &q_clean2,
            c_low,
            false,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    } else if secp_direct_const_arith_enabled() {
        add_nbit_const_direct_uncontrolled_fast(b, &acc_ext, c);
    } else {
        let n1 = acc_ext.len();
        let ca = load_const(b, n1, c);
        add_nbit_qq_fast(b, &ca, &acc_ext);
        unload_const(b, &ca, c);
    }
    let flag = b.alloc_qubit();
    b.cx(acc_ovf, flag);
    b.x(flag);

    if use_vent {
        let c_low = c.as_limbs()[0];
        let n1 = acc_ext.len();
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::cisub_dirty_2clean_classical(
            b,
            &acc_ext,
            &a_ext[..n1 - 2],
            &q_clean2,
            c_low,
            flag,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    } else if secp_direct_const_arith_enabled() {
        csub_nbit_const_direct_fast(b, &acc_ext, c, flag);
    } else {
        let n1 = acc_ext.len();
        let ca = b.alloc_qubits(n1);
        for i in 0..n1 {
            if bit(c, i) {
                b.cx(flag, ca[i]);
            }
        }
        sub_nbit_qq_fast(b, &ca, &acc_ext);
        for i in 0..n1 {
            if bit(c, i) {
                b.cx(flag, ca[i]);
            }
        }
        b.free_vec(&ca);
    }
    b.x(flag);
    b.cx(flag, acc_ovf);
    if std::env::var("MOD_FAST_FLAG_CONDITIONAL_REPLAY").ok().as_deref() == Some("1") {
        let phase = b.alloc_bit();
        b.hmr(flag, phase);
        cmp_lt_phase_conditioned(b, &acc_ext[..n], &a_ext[..n], phase);
    } else {
        cmp_lt_into_fast(b, &acc_ext[..n], &a_ext[..n], flag);
    }
    b.free(flag);

    unext_reg(b, a_ovf);
    unext_reg(b, acc_ovf);
    let _ = (acc_ext, a_ext);
}

pub(crate) fn mod_add_qq_fast_from_zero(b: &mut B, acc: &[QubitId], a: &[QubitId], p: U256) {
    let n = acc.len();
    assert_eq!(n, a.len());
    debug_assert_eq!(n, 256);

    let (acc_ext, acc_ovf) = ext_reg(b, acc);
    let (a_ext, a_ovf) = ext_reg(b, a);

    for i in 0..n {
        b.cx(a[i], acc[i]);
    }

    let c = U256::MAX.wrapping_sub(p).wrapping_add(U256::from(1));
    let use_vent = kal_vent_modadd_enabled();
    if use_vent {
        let n1 = acc_ext.len();
        let c_low = c.as_limbs()[0];
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::iadd_dirty_2clean_classical(
            b,
            &acc_ext,
            &a_ext[..n1 - 2],
            &q_clean2,
            c_low,
            false,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    } else {
        let n1 = acc_ext.len();
        let ca = load_const(b, n1, c);
        add_nbit_qq_fast(b, &ca, &acc_ext);
        unload_const(b, &ca, c);
    }
    let flag = b.alloc_qubit();
    b.cx(acc_ovf, flag);
    b.x(flag);
    if use_vent {
        let c_low = c.as_limbs()[0];
        let n1 = acc_ext.len();
        let q_clean2: [QubitId; 2] = [b.alloc_qubit(), b.alloc_qubit()];
        venting::cisub_dirty_2clean_classical(
            b,
            &acc_ext,
            &a_ext[..n1 - 2],
            &q_clean2,
            c_low,
            flag,
        );
        b.free(q_clean2[0]);
        b.free(q_clean2[1]);
    } else {
        let n1 = acc_ext.len();
        let ca = b.alloc_qubits(n1);
        for i in 0..n1 {
            if bit(c, i) {
                b.cx(flag, ca[i]);
            }
        }
        sub_nbit_qq_fast(b, &ca, &acc_ext);
        for i in 0..n1 {
            if bit(c, i) {
                b.cx(flag, ca[i]);
            }
        }
        b.free_vec(&ca);
    }
    b.x(flag);
    b.cx(flag, acc_ovf);
    if std::env::var("MOD_FAST_FLAG_CONDITIONAL_REPLAY").ok().as_deref() == Some("1") {
        let phase = b.alloc_bit();
        b.hmr(flag, phase);
        cmp_lt_phase_conditioned(b, &acc_ext[..n], &a_ext[..n], phase);
    } else {
        cmp_lt_into_fast(b, &acc_ext[..n], &a_ext[..n], flag);
    }
    b.free(flag);

    unext_reg(b, a_ovf);
    unext_reg(b, acc_ovf);
    let _ = (acc_ext, a_ext);
}

pub(crate) fn cmod_add_qq(b: &mut B, acc: &[QubitId], a: &[QubitId], ctrl: QubitId, p: U256) {
    let n = acc.len();
    let f = b.alloc_qubits(n);
    for i in 0..n {
        b.ccx(ctrl, a[i], f[i]);
    }
    mod_add_qq_fast(b, acc, &f, p);

    for i in 0..n {
        let m = b.alloc_bit();
        b.hmr(f[i], m);
        b.cz_if(ctrl, a[i], m);
    }
    b.free_vec(&f);
}

pub(crate) fn cmod_sub_qq(b: &mut B, acc: &[QubitId], a: &[QubitId], ctrl: QubitId, p: U256) {
    let n = acc.len();
    let f = b.alloc_qubits(n);
    for i in 0..n {
        b.ccx(ctrl, a[i], f[i]);
    }
    mod_sub_qq_fast(b, acc, &f, p);
    for i in 0..n {
        let m = b.alloc_bit();
        b.hmr(f[i], m);
        b.cz_if(ctrl, a[i], m);
    }
    b.free_vec(&f);
}

pub(crate) fn cmod_add_qq_lowq(b: &mut B, acc: &[QubitId], a: &[QubitId], ctrl: QubitId, p: U256) {
    let n = acc.len();
    let f = b.alloc_qubits(n);
    for i in 0..n {
        b.ccx(ctrl, a[i], f[i]);
    }
    mod_add_qq(b, acc, &f, p);
    for i in 0..n {
        let m = b.alloc_bit();
        b.hmr(f[i], m);
        b.cz_if(ctrl, a[i], m);
    }
    b.free_vec(&f);
}

pub(crate) fn cmod_sub_qq_lowq(b: &mut B, acc: &[QubitId], a: &[QubitId], ctrl: QubitId, p: U256) {
    let n = acc.len();
    let f = b.alloc_qubits(n);
    for i in 0..n {
        b.ccx(ctrl, a[i], f[i]);
    }
    mod_sub_qq(b, acc, &f, p);
    for i in 0..n {
        let m = b.alloc_bit();
        b.hmr(f[i], m);
        b.cz_if(ctrl, a[i], m);
    }
    b.free_vec(&f);
}
